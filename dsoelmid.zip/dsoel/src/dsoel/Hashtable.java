package dsoel;

public class Hashtable {
	boolean used[]= new boolean[1000];
	
	public boolean isduplicate(int id) {
		if(used[id]) {
			return true;
		}
		used[id]=true;
		return false;
		
	}

}

