package dsoel;

public class Report {
    void sortByArea(Complaint[] arr) {
        mergeSortByArea(arr, 0, arr.length - 1);
    }

    void mergeSortByArea(Complaint[] arr, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;

            mergeSortByArea(arr, left, mid);
            mergeSortByArea(arr, mid + 1, right);

            mergeArea(arr, left, mid, right);
        }
    }

    void mergeArea(Complaint[] arr, int left, int mid, int right) {
        Complaint[] temp = new Complaint[right - left + 1];

        int i = left, j = mid + 1, k = 0;

        while (i <= mid && j <= right) {
            if (arr[i].area.compareTo(arr[j].area) <= 0)
                temp[k++] = arr[i++];
            else
                temp[k++] = arr[j++];
        }

        while (i <= mid) temp[k++] = arr[i++];
        while (j <= right) temp[k++] = arr[j++];

        System.arraycopy(temp, 0, arr, left, temp.length);
    }

    void sortBySeverity(Complaint[] arr) {
        for (int i = 1; i < arr.length; i++) {
            Complaint key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j].getPriority() > key.getPriority()) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }

    void sortByTime(Complaint[] arr) {
        mergeSortByTime(arr, 0, arr.length - 1);
    }

    void mergeSortByTime(Complaint[] arr, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;

            mergeSortByTime(arr, left, mid);
            mergeSortByTime(arr, mid + 1, right);

            mergeTime(arr, left, mid, right);
        }
    }

    void mergeTime(Complaint[] arr, int left, int mid, int right) {
        Complaint[] temp = new Complaint[right - left + 1];

        int i = left, j = mid + 1, k = 0;

        while (i <= mid && j <= right) {
            if (convertTime(arr[i].time) <= convertTime(arr[j].time))
                temp[k++] = arr[i++];
            else
                temp[k++] = arr[j++];
        }

        while (i <= mid) temp[k++] = arr[i++];
        while (j <= right) temp[k++] = arr[j++];

        System.arraycopy(temp, 0, arr, left, temp.length);
    }
    int convertTime(String t) {
        String[] p = t.split(":");
        return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
    }
}
