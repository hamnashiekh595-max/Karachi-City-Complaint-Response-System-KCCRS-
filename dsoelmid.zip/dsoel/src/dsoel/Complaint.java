package dsoel;

public class Complaint {
	int id;
	String name;
	String area;
	String type;
	String severity;
	String time;
	
	public Complaint(int id,String name,String area,String type,String severity,String time) {
		this.id=id;
		this.name=name;
		this.area=area;
		this.type=type;
		this.severity=severity;
		this.time=time;
	}
	public int getPriority() {
		switch(severity.toLowerCase()) {
		case "critical":return 1;
		case" medium" : return 2;
		case "low" :return 3;
		default : return 4;
		}	
	}
	public int getPriorty () {
		return getPriority();
		
	}
		
	    public String toString() {
	        return id + "   " + name + "  " + area + "  " + type + "  " + severity + "  " + time;
	}
}
