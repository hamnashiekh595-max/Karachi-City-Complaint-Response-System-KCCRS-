package dsoel;


import java.util.Comparator;
import java.util.PriorityQueue;

public class ComplaintPriorityQueue {
	 PriorityQueue<Complaint> heap;
	 public ComplaintPriorityQueue() {
		    heap = new PriorityQueue<>(Comparator.comparingInt(Complaint::getPriority));
		}

	    void push(Complaint c) {
	        heap.add(c);
	        System.out.println("Added complaint: " + c.id);
	    }

	    Complaint pop() {
	        if (heap.isEmpty()) return null;
	        return heap.poll();
	    }
	    Complaint peek() {
	        if (heap.isEmpty()) return null;
	        return heap.peek();
	    }

	    void displayHeap() {
	        if (heap.isEmpty()) {
	            System.out.println("No complaints in heap.");
	            return;
	        }
	        System.out.println("Heap contents:");
	        for (Complaint c : heap) {
	            System.out.println(c);
	        }
	    }
	}
