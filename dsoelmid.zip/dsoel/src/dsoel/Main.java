package dsoel;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Complaintlist complaintList = new Complaintlist();
        Hashtable hashTable = new Hashtable();
        ComplaintPriorityQueue priorityQueue = new ComplaintPriorityQueue();
        ComplaintProcessingQueue processingQueue = new ComplaintProcessingQueue();
        Doublylinkedlist historyList = new Doublylinkedlist();
        Undooperation undo = new Undooperation();
        Report report = new Report();

        while (true) {
            System.out.println("\n===== Karachi City Complaint & Response System (KCCRS) =====");
            System.out.println("1. Add Complaint");
            System.out.println("2. Search Complaint by ID");
            System.out.println("3. Display All Complaints");
            System.out.println("4. Add Complaint to Processing Queue");
            System.out.println("5. Process Next Complaint");
            System.out.println("6. Display Processing Queue");
            System.out.println("7. Display Complaint History");
            System.out.println("8. Undo Last Added Complaint");
            System.out.println("9. Undo Last Processed Complaint");
            System.out.println("10. Generate Report (Sort by Area, Severity, Time)");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            
            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    if (hashTable.isduplicate(id)) {
                        System.out.println("Complaint ID already exists!");
                        break;
                    }
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Area: ");
                    String area = sc.nextLine();
                    System.out.print("Enter Type: ");
                    String type = sc.nextLine();
                    System.out.print("Enter Severity (critical/medium/low): ");
                    String severity = sc.nextLine();
                    System.out.print("Enter Time (HH:MM): ");
                    String time = sc.nextLine();

                    Complaint c = new Complaint(id, name, area, type, severity, time);
                    complaintList.add(c);
                    priorityQueue.push(c);
                    historyList.add(c);
                    undo.recordAdd(c);
                    break;

                case 2: 
                    System.out.print("Enter Complaint ID to search: ");
                    int searchId = sc.nextInt();
                    Complaint found = complaintList.search(searchId);
                    if (found != null)
                        System.out.println("Found: " + found);
                    else
                        System.out.println("Complaint not found!");
                    break;

                case 3:
                    complaintList.displayall();
                    break;

                case 4: 
                    System.out.print("Enter Complaint ID to enqueue: ");
                    int enqueueId = sc.nextInt();
                    processingQueue.enqueue(enqueueId);
                    break;

                case 5: 
                    Integer processId = processingQueue.dequeue();
                    if (processId != null) {
                        Complaint processed = complaintList.search(processId);
                        if (processed != null) {
                            undo.recordProcessed(processed);
                            System.out.println("Processed Complaint: " + processed);
                        }
                    }
                    break;

                case 6:
                    processingQueue.displayQueue();
                    break;

                case 7: 
                    System.out.println("1. Forward History\n2. Backward History");
                    int histChoice = sc.nextInt();
                    if (histChoice == 1)
                        historyList.displayForward();
                    else
                        historyList.displayBackward();
                    break;

                case 8: 
                    Complaint undoneAdd = undo.undoLastAdded();
                    if (undoneAdd != null)
                        System.out.println("Removed from system: " + undoneAdd);
                    break;

                case 9: 
                    Complaint undoneProcess = undo.undoLastProcessed();
                    if (undoneProcess != null)
                        System.out.println("Restored to queue: " + undoneProcess);
                    break;

                case 10: 
                    System.out.println("Sort by: 1. Area 2. Severity 3. Time");
                    int reportChoice = sc.nextInt();
                    Complaint[] allComplaints = new Complaint[1000];
                    int count = 0;
                    
                    Node temp = complaintList.head;
                    while (temp != null) {
                        allComplaints[count++] = temp.data;
                        temp = temp.next;
                    }
                    Complaint[] finalArr = new Complaint[count];
                    System.arraycopy(allComplaints, 0, finalArr, 0, count);

                    switch (reportChoice) {
                        case 1: report.sortByArea(finalArr); break;
                        case 2: report.sortBySeverity(finalArr); break;
                        case 3: report.sortByTime(finalArr); break;
                        default: System.out.println("Invalid choice!"); continue;
                    }
                    System.out.println("Sorted Report:");
                    for (Complaint cmp : finalArr) System.out.println(cmp);
                    break;

                case 0:
                    System.out.println("Exiting system. Goodbye!");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }
}
