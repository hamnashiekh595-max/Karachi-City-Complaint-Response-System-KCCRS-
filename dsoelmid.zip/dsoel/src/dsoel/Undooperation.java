package dsoel;

import java.util.Stack;

public class Undooperation {
	Stack<Complaint> undoAddStack;        
    Stack<Complaint> undoProcessStack;    

    public Undooperation() {
        undoAddStack = new Stack<>();
        undoProcessStack = new Stack<>();
    }
    public void recordAdd(Complaint c) {
        undoAddStack.push(c);
        System.out.println("Recorded Added: " + c.id);
    }

    // Undo last added complaint
    public Complaint undoLastAdded() {
        if (undoAddStack.isEmpty()) {
            System.out.println("No added complaint to undo.");
            return null;
        }
        Complaint undone = undoAddStack.pop();
        System.out.println("Undo Added Complaint: " + undone);
        return undone;
    }
    public void recordProcessed(Complaint c) {
        undoProcessStack.push(c);
        System.out.println("Recorded Processed: " + c.id);
    }

    public Complaint undoLastProcessed() {
        if (undoProcessStack.isEmpty()) {
            System.out.println("No processed complaint to undo.");
            return null;
        }
        Complaint undone = undoProcessStack.pop();
        System.out.println("Undo Processed Complaint: " + undone);
        return undone;
    }
    public void printReverse(Stack<Complaint> stack) {
        if (stack.isEmpty()) return;

        Complaint top = stack.pop(); 
        printReverse(stack);         
        System.out.println(top);    
        stack.push(top);             
    }
    public void printAddedReverse() {
        System.out.println("\nReverse Added Complaints:");
        printReverse(undoAddStack);
    }

    public void printProcessedReverse() {
        System.out.println("\nReverse Processed Complaints:");
        printReverse(undoProcessStack);
    }
}


