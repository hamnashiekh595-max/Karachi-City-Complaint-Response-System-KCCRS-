package dsoel;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Optional;

public class KCCRSApp extends Application {
 private final ComplaintList complaintList = new ComplaintList();
 private final SimpleHashTable hashTable = new SimpleHashTable(101); 
 private final ComplaintMinHeap priorityHeap = new ComplaintMinHeap();
 private final IntQueue processingQueue = new IntQueue(); 
 private final SimpleStack<String> undoStack = new SimpleStack<>(); 

 private final TextArea outputArea = new TextArea();

 
 private int nextId = 1000;

 public static void main(String[] args) {
     launch(args);
 }

 @Override
 public void start(Stage primaryStage) {
     primaryStage.setTitle("KCCRS - All-in-One (Single Class)");
     Button addBtn = new Button("Add Complaint");
     Button viewAllBtn = new Button("View All Complaints");
     Button searchBtn = new Button("Search by ID");
     Button showHeapBtn = new Button("Show Priority Heap");
     Button popHeapBtn = new Button("Pop Next Urgent");
     Button enqueueBtn = new Button("Enqueue for Processing");
     Button dequeueBtn = new Button("Dequeue (Process)");
     Button showQueueBtn = new Button("Show Processing Queue");
     Button dailyReportBtn = new Button("Daily Report (Sort by area)");
     Button undoBtn = new Button("Undo Last Operation");
     Button clearBtn = new Button("Clear Output");

     addBtn.setOnAction(e -> handleAddComplaint());
     viewAllBtn.setOnAction(e -> printOutput(complaintList.display()));
     searchBtn.setOnAction(e -> handleSearchById());
     showHeapBtn.setOnAction(e -> printOutput(priorityHeap.display()));
     popHeapBtn.setOnAction(e -> handlePopHeap());
     enqueueBtn.setOnAction(e -> handleEnqueue());
     dequeueBtn.setOnAction(e -> handleDequeue());
     showQueueBtn.setOnAction(e -> printOutput(processingQueue.display()));
     dailyReportBtn.setOnAction(e -> handleDailyReport());
     undoBtn.setOnAction(e -> handleUndo());
     clearBtn.setOnAction(e -> outputArea.clear());
     VBox left = new VBox(10,
             addBtn, searchBtn, viewAllBtn,
             new Separator(),
             showHeapBtn, popHeapBtn,
             new Separator(),
             enqueueBtn, dequeueBtn, showQueueBtn,
             new Separator(),
             dailyReportBtn,
             new Separator(),
             undoBtn, clearBtn
     );
     left.setPadding(new Insets(10));
     left.setPrefWidth(230);

     outputArea.setEditable(false);
     outputArea.setWrapText(true);
     outputArea.setPrefWidth(600);

     HBox root = new HBox(left, outputArea);
     Scene scene = new Scene(root, 860, 520);
     primaryStage.setScene(scene);
     primaryStage.show();
 }


 private void handleAddComplaint() {
  
     Dialog<Pair<String, String>> dialog = new Dialog<>();
     dialog.setTitle("Add Complaint");
     dialog.setHeaderText("Enter complaint details (area,type,severity,name). Time auto-filled.");
     ButtonType addType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
     dialog.getDialogPane().getButtonTypes().addAll(addType, ButtonType.CANCEL);

     GridPane grid = new GridPane();
     grid.setHgap(10);
     grid.setVgap(10);
     grid.setPadding(new Insets(20, 150, 10, 10));

     TextField nameField = new TextField();
     nameField.setPromptText("Citizen name (e.g., Ali)");
     TextField areaField = new TextField();
     areaField.setPromptText("Area (Korangi, Saddar...)");
     TextField typeField = new TextField();
     typeField.setPromptText("Type (Water, Garbage...)");
     ChoiceBox<String> severityBox = new ChoiceBox<>();
     severityBox.getItems().addAll("Low", "Medium", "High", "Critical");
     severityBox.setValue("Medium");

     grid.add(new Label("Name:"), 0, 0);
     grid.add(nameField, 1, 0);
     grid.add(new Label("Area:"), 0, 1);
     grid.add(areaField, 1, 1);
     grid.add(new Label("Type:"), 0, 2);
     grid.add(typeField, 1, 2);
     grid.add(new Label("Severity:"), 0, 3);
     grid.add(severityBox, 1, 3);

     dialog.getDialogPane().setContent(grid);

     Platform.runLater(nameField::requestFocus);

     dialog.setResultConverter(dialogButton -> {
         if (dialogButton == addType) {
             String joined = nameField.getText().trim() + ";;" + areaField.getText().trim()
                     + ";;" + typeField.getText().trim() + ";;" + severityBox.getValue();
             return new Pair<>("ADD", joined);
         }
         return null;
     });

     Optional<Pair<String, String>> result = dialog.showAndWait();

     result.ifPresent(pair -> {
         String data = pair.getValue();
         String[] parts = data.split(";;");
         String name = parts[0].isEmpty() ? "Unknown" : parts[0];
         String area = parts.length > 1 && !parts[1].isEmpty() ? parts[1] : "Unknown";
         String type = parts.length > 2 && !parts[2].isEmpty() ? parts[2] : "Other";
         String severity = parts.length > 3 && !parts[3].isEmpty() ? parts[3] : "Low";

         int id = nextId++;
         String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
         Complaint c = new Complaint(id, name, area, type, severity, time);

         if (hashTable.contains(id)) {
             printOutput("Duplicate complaint ID detected (shouldn't happen with incremental IDs).");
             return;
         }

         complaintList.addLast(c);            
         hashTable.insert(id);               
         priorityHeap.insert(c);             
         processingQueue.enqueue(id);        
         undoStack.push("ADD:" + id);        

         printOutput("Added complaint:\n" + c);
     });
 }

 private void handleSearchById() {
     TextInputDialog tid = new TextInputDialog();
     tid.setTitle("Search Complaint");
     tid.setHeaderText("Enter Complaint ID to search");
     tid.setContentText("ID:");
     Optional<String> res = tid.showAndWait();
     res.ifPresent(s -> {
         try {
             int id = Integer.parseInt(s.trim());
             Complaint c = complaintList.findById(id);
             if (c == null) printOutput("Complaint not found with ID: " + id);
             else printOutput("Found: " + c);
         } catch (NumberFormatException ex) {
             printOutput("Invalid ID input.");
         }
     });
 }

 private void handlePopHeap() {
     Complaint c = priorityHeap.pop();
     if (c == null) {
         printOutput("No urgent complaints in heap.");
         return;
     }
     undoStack.push("POP_HEAP:" + c.id);
     printOutput("Popped highest priority complaint:\n" + c);
 }

 private void handleEnqueue() {
     TextInputDialog tid = new TextInputDialog();
     tid.setTitle("Enqueue Complaint ID");
     tid.setHeaderText("Enter Complaint ID to enqueue for processing (FIFO)");
     tid.setContentText("ID:");
     Optional<String> res = tid.showAndWait();
     res.ifPresent(s -> {
         try {
             int id = Integer.parseInt(s.trim());
             if (complaintList.findById(id) == null) {
                 printOutput("No complaint found with ID: " + id);
                 return;
             }
             processingQueue.enqueue(id);
             undoStack.push("ENQ:" + id);
             printOutput("Enqueued ID: " + id);
         } catch (NumberFormatException ex) {
             printOutput("Invalid ID.");
         }
     });
 }

 private void handleDequeue() {
     if (processingQueue.isEmpty()) {
         printOutput("Processing queue is empty.");
         return;
     }
     int id = processingQueue.dequeue();
     undoStack.push("DEQ:" + id);
     printOutput("Dequeued (processing) complaint ID: " + id);
 }

 private void handleDailyReport() {
     ArrayList<Complaint> arr = complaintList.toArray();
     if (arr.isEmpty()) {
         printOutput("No complaints to generate report.");
         return;
     }
     Complaint[] arrA = arr.toArray(new Complaint[0]);
     mergeSortByArea(arrA);

     StringBuilder sb = new StringBuilder("Daily Report - Sorted by Area (MergeSort, O(n log n)):\n");
     for (Complaint c : arrA) sb.append(c).append("\n");
     printOutput(sb.toString());
 }

 private void handleUndo() {
     if (undoStack.isEmpty()) {
         printOutput("Nothing to undo.");
         return;
     }
     String op = undoStack.pop();
     if (op.startsWith("ADD:")) {
         int id = Integer.parseInt(op.split(":")[1]);
         boolean removed = complaintList.removeById(id);
         if (removed) {
             hashTable.remove(id);
             priorityHeap.removeById(id);
             processingQueue.remove(id); 
             printOutput("Undid add: removed complaint ID " + id);
         } else {
             printOutput("Undo failed: ID " + id + " not found.");
         }
     } else if (op.startsWith("POP_HEAP:")) {
         printOutput("Undo for POP_HEAP not implemented in this simple demo.");
     } else if (op.startsWith("ENQ:")) {
         int id = Integer.parseInt(op.split(":")[1]);
         processingQueue.remove(id);
         printOutput("Undid enqueue of ID " + id);
     } else if (op.startsWith("DEQ:")) {
         int id = Integer.parseInt(op.split(":")[1]);
         processingQueue.enqueue(id);
         printOutput("Undid dequeue: re-enqueued ID " + id);
     } else {
         printOutput("Unknown undo operation: " + op);
     }
 }

 private void printOutput(String text) {
     outputArea.appendText(text + "\n\n");
 }

 

 private static class Complaint {
     int id;
     String name;
     String area;
     String type;
     String severity;
     String time;

     Complaint(int id, String name, String area, String type, String severity, String time) {
         this.id = id;
         this.name = name;
         this.area = area;
         this.type = type;
         this.severity = severity;
         this.time = time;
     }

     int getPriorityValue() {
         switch (severity.toLowerCase()) {
             case "critical": return 1;
             case "high": return 2;
             case "medium": return 3;
             default: return 4;
         }
     }

     @Override
     public String toString() {
         return String.format("[%d] %s | %s | %s | %s @ %s", id, name, area, type, severity, time);
     }
 }

 
 private static class ComplaintList {
     private static class Node {
         Complaint data;
         Node next;
         Node(Complaint c) { data = c; }
     }
     private Node head = null;
     private Node tail = null;
     private int size = 0;

     void addLast(Complaint c) {
         Node n = new Node(c);
         if (head == null) {
             head = tail = n;
         } else {
             tail.next = n;
             tail = n;
         }
         size++;
     }

     Complaint findById(int id) {
         Node cur = head;
         while (cur != null) {
             if (cur.data.id == id) return cur.data;
             cur = cur.next;
         }
         return null;
     }

     boolean removeById(int id) {
         Node cur = head, prev = null;
         while (cur != null) {
             if (cur.data.id == id) {
                 if (prev == null) head = cur.next;
                 else prev.next = cur.next;
                 if (cur == tail) tail = prev;
                 size--;
                 return true;
             }
             prev = cur;
             cur = cur.next;
         }
         return false;
     }

     ArrayList<Complaint> toArray() {
         ArrayList<Complaint> out = new ArrayList<>();
         Node cur = head;
         while (cur != null) {
             out.add(cur.data);
             cur = cur.next;
         }
         return out;
     }

     String display() {
         if (head == null) return "No complaints stored.";
         StringBuilder sb = new StringBuilder("All Complaints:\n");
         Node cur = head;
         while (cur != null) {
             sb.append(cur.data).append("\n");
             cur = cur.next;
         }
         return sb.toString();
     }
 }

 private static class SimpleHashTable {
     private final Integer[] table;

     SimpleHashTable(int capacity) { table = new Integer[capacity]; }

     private int hash(int key) { return Math.abs(key) % table.length; }

     void insert(int key) {
         int idx = hash(key);
         int start = idx;
         while (table[idx] != null && !table[idx].equals(key)) {
             idx = (idx + 1) % table.length;
             if (idx == start) throw new RuntimeException("Hash table full");
         }
         table[idx] = key;
     }

     boolean contains(int key) {
         int idx = hash(key);
         int start = idx;
         while (table[idx] != null) {
             if (table[idx].equals(key)) return true;
             idx = (idx + 1) % table.length;
             if (idx == start) break;
         }
         return false;
     }

     void remove(int key) {
         int idx = hash(key);
         int start = idx;
         while (table[idx] != null) {
             if (table[idx].equals(key)) {
                 table[idx] = null;
                 return;
             }
             idx = (idx + 1) % table.length;
             if (idx == start) break;
         }
     }
 }
 private static class ComplaintMinHeap {
     private final ArrayList<Complaint> heap = new ArrayList<>();

     void insert(Complaint c) {
         heap.add(c);
         siftUp(heap.size() - 1);
     }

     Complaint pop() {
         if (heap.isEmpty()) return null;
         Complaint root = heap.get(0);
         Complaint last = heap.remove(heap.size() - 1);
         if (!heap.isEmpty()) {
             heap.set(0, last);
             siftDown(0);
         }
         return root;
     }

     boolean isEmpty() { return heap.isEmpty(); }

     private void siftUp(int i) {
         while (i > 0) {
             int p = (i - 1) / 2;
             if (heap.get(i).getPriorityValue() < heap.get(p).getPriorityValue()) {
                 swap(i, p);
                 i = p;
             } else break;
         }
     }

     private void siftDown(int i) {
         int n = heap.size();
         while (true) {
             int left = 2 * i + 1, right = 2 * i + 2, smallest = i;
             if (left < n && heap.get(left).getPriorityValue() < heap.get(smallest).getPriorityValue())
                 smallest = left;
             if (right < n && heap.get(right).getPriorityValue() < heap.get(smallest).getPriorityValue())
                 smallest = right;
             if (smallest != i) {
                 swap(i, smallest);
                 i = smallest;
             } else break;
         }
     }

     private void swap(int a, int b) {
         Complaint t = heap.get(a);
         heap.set(a, heap.get(b));
         heap.set(b, t);
     }

     String display() {
         if (heap.isEmpty()) return "Priority heap is empty.";
         StringBuilder sb = new StringBuilder("Priority Heap (array order):\n");
         for (Complaint c : heap) sb.append(c).append("\n");
         return sb.toString();
     }
     void removeById(int id) {
         int idx = -1;
         for (int i = 0; i < heap.size(); i++) {
             if (heap.get(i).id == id) { idx = i; break; }
         }
         if (idx == -1) return;
         int last = heap.size() - 1;
         if (idx != last) {
             heap.set(idx, heap.remove(last));
             siftDown(idx);
             siftUp(idx);
         } else heap.remove(last);
     }
 }
 private static class IntQueue {
     private final ArrayList<Integer> data = new ArrayList<>();
     private int head = 0;

     void enqueue(int id) { data.add(id); }

     int dequeue() {
         if (isEmpty()) throw new RuntimeException("Queue empty");
         int val = data.get(head);
         head++;
         if (head > 50 && head * 2 > data.size()) { // occasional compacting
             ArrayList<Integer> newData = new ArrayList<>(data.subList(head, data.size()));
             data.clear();
             data.addAll(newData);
             head = 0;
         }
         return val;
     }

     boolean isEmpty() { return head >= data.size(); }

     String display() {
         if (isEmpty()) return "Processing queue empty.";
         StringBuilder sb = new StringBuilder("Processing Queue (FIFO):\n");
         for (int i = head; i < data.size(); i++) sb.append(data.get(i)).append(i == data.size()-1 ? "" : ", ");
         return sb.toString();
     }
     void remove(int id) {
         ArrayList<Integer> newList = new ArrayList<>();
         for (int i = head; i < data.size(); i++) {
             int v = data.get(i);
             if (v != id) newList.add(v);
         }
         data.clear();
         data.addAll(newList);
         head = 0;
     }
 }
 private static class SimpleStack<T> {
     private final ArrayList<T> data = new ArrayList<>();
     void push(T item) { data.add(item); }
     T pop() { return data.isEmpty() ? null : data.remove(data.size() - 1); }
     boolean isEmpty() { return data.isEmpty(); }
 }
 private static void mergeSortByArea(Complaint[] arr) {
     if (arr.length <= 1) return;
     Complaint[] aux = new Complaint[arr.length];
     mergeSortRec(arr, aux, 0, arr.length - 1);
 }

 private static void mergeSortRec(Complaint[] arr, Complaint[] aux, int lo, int hi) {
     if (lo >= hi) return;
     int mid = (lo + hi) / 2;
     mergeSortRec(arr, aux, lo, mid);
     mergeSortRec(arr, aux, mid + 1, hi);
     merge(arr, aux, lo, mid, hi);
 }

 private static void merge(Complaint[] arr, Complaint[] aux, int lo, int mid, int hi) {
     System.arraycopy(arr, lo, aux, lo, hi - lo + 1);
     int i = lo, j = mid + 1, k = lo;
     while (i <= mid && j <= hi) {
         if (aux[i].area.compareToIgnoreCase(aux[j].area) <= 0) arr[k++] = aux[i++];
         else arr[k++] = aux[j++];
     }
     while (i <= mid) arr[k++] = aux[i++];
     while (j <= hi) arr[k++] = aux[j++];
 }
}
