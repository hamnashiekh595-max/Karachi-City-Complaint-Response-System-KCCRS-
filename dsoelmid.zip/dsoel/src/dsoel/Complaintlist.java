package dsoel;

 class Node{
	Complaint data;
	Node next;
	
	public Node(Complaint c) {
		this.data=c;
		this.next=null;
		
	}
}

public class Complaintlist {
	Node head;
	
	public void add(Complaint c) {
		Node n =new Node(c);
		n.next=head;
		head=n;
		System.out.println("complaint added");
	}
	public Complaint search(int id) {
		Node temp=head;
		while(temp!=null) {
			if(temp.data.id==id) {
				return temp.data;
		  
			}
			temp = temp.next;
		}
		  return null;
		
	}
	public void displayall() {
		Node temp=head;
		if(head==null) {
			System.out.println("no Complaints avaliable");
			return;
		}
		while (temp != null) {
            System.out.println(temp.data);
            temp = temp.next;
	}


	
	}
}
