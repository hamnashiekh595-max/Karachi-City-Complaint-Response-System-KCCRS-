package dsoel;

import java.util.LinkedList;
import java.util.Queue;

public class ComplaintProcessingQueue {

    Queue<Integer> queue; 

    public ComplaintProcessingQueue() {
        queue = new LinkedList<>();
    }

    public void enqueue(int complaintId) {
        queue.add(complaintId);
        System.out.println("Enqueued complaint ID: " + complaintId);
    }

    public Integer dequeue() {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty. No complaints to process.");
            return null;
        }
        Integer id = queue.poll();
        System.out.println("Dequeued complaint ID: " + id);
        return id;
    }
    public void displayQueue() {
        if (queue.isEmpty()) {
            System.out.println("No pending complaints in queue.");
            return;
        }
        System.out.println("Pending complaints in queue:");
        for (Integer id : queue) {
            System.out.print(id + " ");
        }
        System.out.println();
    }

   
}
