package dsoel;

public class Doublylinkedlist {
    public class Node {
        Complaint data;
        Node prev, next;

        Node(Complaint data) {
            this.data = data;
            this.prev = this.next = null;
        }
    }

    private Node head;
    private Node tail;
    private Node current; 
    public Doublylinkedlist() {
        head = tail = current = null;
    }

    public void add(Complaint c) {
        Node newNode = new Node(c);

        if (head == null) {
            head = tail = current = newNode; 
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }

        System.out.println("Added to history: " + c.id);
    }

    public Complaint getCurrent() {
        if (current == null) {
            System.out.println("History is empty.");
            return null;
        }
        return current.data;
    }

    public Complaint moveNext() {
        if (current == null) return null;

        if (current.next != null) {
            current = current.next;
            return current.data;
        } else {
            System.out.println("Already at most recent record.");
            return current.data;
        }
    }

    public Complaint movePrev() {
        if (current == null) return null;

        if (current.prev != null) {
            current = current.prev;
            return current.data;
        } else {
            System.out.println("Already at oldest record.");
            return current.data;
        }
    }
    public void displayForward() {
        if (head == null) {
            System.out.println("No history available.");
            return;
        }
        Node temp = head;
        System.out.println("History (Oldest to Newest):");
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.next;
        }
    }

    public void displayBackward() {
        if (tail == null) {
            System.out.println("No history available.");
            return;
        }
        Node temp = tail;
        System.out.println("History (Newest to Oldest):");
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.prev;
        }
    }
}
